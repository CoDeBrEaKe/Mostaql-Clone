import {
  DataType,
  Column,
  Table,
  ForeignKey,
  Model,
  BelongsTo,
  Unique,
} from "sequelize-typescript";
import {
  CreationOptional,
  InferAttributes,
  InferCreationAttributes,
} from "sequelize";
import User from "./User";

@Table({
  modelName: "FreelancerProfile",
  tableName: "freelancersprofiles",
})
export default class FreelancerProfile extends Model<
  InferAttributes<FreelancerProfile>,
  InferCreationAttributes<FreelancerProfile>
> {
  @Column({
    primaryKey: true,
    autoIncrement: true,
    type: DataType.INTEGER,
  })
  declare id: CreationOptional<number>;

  @Unique("unique_user_id")
  @ForeignKey(() => User)
  @Column({
    type: DataType.INTEGER,
  })
  declare user_id: number;

  @Column({
    type: DataType.STRING,
    defaultValue: "",
  })
  declare bio: String;

  @Column({
    type: DataType.INTEGER,
    defaultValue: 10,
  })
  declare available_bids: number;

  @BelongsTo(() => User)
  declare user: User;

  toJSON() {
    return {
      ...this.get(),
      id: undefined,
    };
  }
}
